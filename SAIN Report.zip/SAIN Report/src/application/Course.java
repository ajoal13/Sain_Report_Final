package application;

public class Course {

}
