package application;

public class Major {

}
