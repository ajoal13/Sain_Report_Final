package application;

public class MajorBag {

}
