package application;

public class SearchView {

}
