package application;

public class Address {

}
